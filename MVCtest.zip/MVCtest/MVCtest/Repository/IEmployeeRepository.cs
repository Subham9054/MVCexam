﻿using MVCtest.Models;

namespace MVCtest.Repository
{
    public interface IEmployeeRepository
    {
        public Task<List<EmployeeDesignation>> GetDesignation();
        public Task<List<DesignationGrade>> Getgrade(int dcode);
        public Task<bool> InsertEmployee(Employee employee);
        public Task<List<Employee>> GetEmployee();
        public Task<bool> DeleteEmployee(string phoneNumber);
        public Task<bool> UpdateEmployee(Employee employee);
        public Task<List<Employee>> GetEmployeeByPhoneNumber(string phoneNumber);
    }
}
