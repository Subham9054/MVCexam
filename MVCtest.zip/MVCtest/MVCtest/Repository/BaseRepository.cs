﻿using System.Data.SqlClient;

namespace MVCtest.Repository
{
    public class BaseRepository
    {
        private readonly IConfiguration _configuration;
        public BaseRepository(IConfiguration configuration)
        {
            _configuration = configuration;
        }
        public SqlConnection myCon()
        {
            return new SqlConnection(_configuration.GetConnectionString("myCon"));
        }
    }
}
