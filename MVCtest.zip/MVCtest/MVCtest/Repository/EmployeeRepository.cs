﻿using System.Data.SqlClient;
using System.Data;
using MVCtest.Models;
using Dapper;
using Microsoft.AspNetCore.Mvc;

namespace MVCtest.Repository
{
    public class EmployeeRepository : BaseRepository, IEmployeeRepository
    {
        public EmployeeRepository(IConfiguration configuration) : base(configuration)
        {

        }
        public async Task<List<EmployeeDesignation>> GetDesignation()
        {
            SqlConnection sqlConnection = myCon();
            try
            {
                DynamicParameters param = new DynamicParameters();
                param.Add("@Action", "GS");
                List<EmployeeDesignation> designations = SqlMapper.Query<EmployeeDesignation>(sqlConnection, "USP_Registration", param, commandType: CommandType.StoredProcedure).ToList();
                return designations;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public async Task<List<DesignationGrade>> Getgrade(int dcode)
        {
            SqlConnection sqlConnection = myCon();
            try
            {
                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@Action", "GD");
                parameters.Add("@dcode", dcode);
                List<DesignationGrade> grades = SqlMapper.Query<DesignationGrade>(sqlConnection, "USP_Registration", parameters, commandType: CommandType.StoredProcedure).ToList();
                return grades;
            }
            catch (Exception ex)
            {
                throw null;
            }
        }

        public async Task<bool> InsertEmployee( Employee employee)
        {
            using (SqlConnection sqlConnection = myCon())
            {
                try
                {
                    DynamicParameters parameters = new DynamicParameters();
                    parameters.Add("@Firstname", employee.Firstname);
                    parameters.Add("@Lastname", employee.Lastname);
                    parameters.Add("@EmailAddress", employee.EmailAddress);
                    parameters.Add("@Phonuenumber", employee.Phonuenumber);
                    parameters.Add("@DesignationIdRef", employee.DesignationIdRef);
                    parameters.Add("@GradeIdRef", employee.GradeIdRef);
                    parameters.Add("@Action", "INSERT");
                    int rowsAffected = await sqlConnection.ExecuteAsync("USP_Registration",parameters,commandType: CommandType.StoredProcedure);
                    return rowsAffected > 0;
                }
                catch (Exception ex)
                {
                    throw;
                }
            }
        }
        public async Task<List<Employee>> GetEmployee()
        {
            using (SqlConnection sqlConnection = myCon())
            {
                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@Action", "RETRIEVE");
                List<Employee> emp = SqlMapper.Query<Employee>(sqlConnection, "USP_Registration", parameters, commandType: CommandType.StoredProcedure).ToList();
                return emp;
            }
        }

        public async Task<bool> DeleteEmployee(string phoneNumber)
        {
            using (SqlConnection sqlConnection = myCon())
            {
                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@Action", "DELETE");
                parameters.Add("@Phonuenumber", phoneNumber);
                var result = await sqlConnection.ExecuteAsync("USP_Registration", parameters, commandType: CommandType.StoredProcedure);
                return result > 0;
            }
        }

        public async Task<List<Employee>> GetEmployeeByPhoneNumber(string phoneNumber)
        {
            using (SqlConnection sqlConnection = myCon())
            {
                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@Action", "GETBYNUMBER");
                List<Employee> emp = SqlMapper.Query<Employee>(sqlConnection, "USP_Registration", parameters, commandType: CommandType.StoredProcedure).ToList();
                return emp;
            }
        }
        public async Task<bool> UpdateEmployee(Employee employee)
        {
            using (SqlConnection sqlConnection = myCon())
            {
                try
                {
                    DynamicParameters parameters = new DynamicParameters();
                    parameters.Add("@Firstname", employee.Firstname);
                    parameters.Add("@Lastname", employee.Lastname);
                    parameters.Add("@EmailAddress", employee.EmailAddress);
                    parameters.Add("@Phonuenumber", employee.Phonuenumber); 
                    parameters.Add("@DesignationIdRef", employee.DesignationIdRef);
                    parameters.Add("@GradeIdRef", employee.GradeIdRef);
                    parameters.Add("@Action", "UPDATE"); // Set action to UPDATE
                    int rowsAffected = await sqlConnection.ExecuteAsync("USP_Registration", parameters, commandType: CommandType.StoredProcedure);
                    return rowsAffected > 0;
                }
                catch (Exception ex)
                {
                    // Handle exception or log it
                    throw;
                }
            }
        }
    }
}
