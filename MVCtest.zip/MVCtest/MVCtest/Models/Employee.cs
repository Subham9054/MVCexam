﻿namespace MVCtest.Models
{
    public class Employee
    {
        public int Id { get; set; }
        public string Firstname { get; set; }
        public string Lastname { get; set; }
        public string EmailAddress { get; set; }
        public string Phonuenumber { get; set; }
        public int DesignationIdRef { get; set; }
        public int GradeIdRef { get; set; }
    }

    public class EmployeeDesignation
    {
        public int Id { get; set; }
        public string DesignationName { get; set; }
        public bool IsActive { get; set; }
    }

    public class DesignationGrade
    {
        public int Id { get; set; }
        public string Gradename { get; set; }
        public int DesignationIdRef { get; set; }
        public bool IsActive { get; set; }
    }
    public class DeleteEmployeeRequest
    {
        public string PhoneNumber { get; set; }
    }


}
