﻿using Microsoft.AspNetCore.Mvc;
using MVCtest.Models;
using MVCtest.Repository;
using System.Diagnostics;

namespace MVCtest.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly IConfiguration _configuration;
        private readonly IEmployeeRepository _employeeRepository;

        public HomeController(ILogger<HomeController> logger,IEmployeeRepository employeeRepository)
        {
            _logger = logger;
            _employeeRepository = employeeRepository;
        }

        public IActionResult Add()
        {
            return View();
        }
        [HttpGet]
        public async Task<JsonResult> GetDesignation()
        {
            try
            {
                var getdesignation = _employeeRepository.GetDesignation();
                if (getdesignation == null)
                {
                    throw new NullReferenceException();
                }
                return Json(getdesignation);
            }
            catch (Exception ex)
            {
                return null;
            }
        }
        [HttpGet]
        public async Task<JsonResult> Getgrade(int dcode)
        {
            try
            {
                var getgrade = _employeeRepository.Getgrade(dcode);
                return Json(getgrade);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        [HttpPost]
        public async Task<IActionResult> Create([FromBody] Employee employee)
        {
            if (ModelState.IsValid)
            {
                bool isInserted = await _employeeRepository.InsertEmployee(employee);
                if (isInserted)
                {
                    return Json(new { success = true });
                }
                else
                {
                    return Json(new { success = false, message = "Error inserting employee." });
                }
            }
            return Json(new { success = false, message = "Invalid data." });
        }
        public async Task<IActionResult> EmployeeReport()
        {
            var employees = await _employeeRepository.GetEmployee();
            return View(employees);
        }
        [HttpPost]
        public async Task<IActionResult> DeleteEmployee([FromBody] DeleteEmployeeRequest request)
        {
            if (request == null || string.IsNullOrEmpty(request.PhoneNumber))
            {
                return Json(new { success = false, message = "Invalid phone number." });
            }

            bool isDeleted = await _employeeRepository.DeleteEmployee(request.PhoneNumber);
            if (isDeleted)
            {
                return Json(new { success = true });
            }
            return Json(new { success = false, message = "Error deleting employee." });
        }


        //public async Task<IActionResult> Update(string phoneNumber)
        //{
        //    // Fetch employee data
        //    var employee = await _employeeRepository.GetEmployeeByPhoneNumber(phoneNumber);
        //    if (employee == null)
        //    {
        //        return NotFound();
        //    }

        //    var designations = await _employeeRepository.GetDesignation();
        //    var grades = await _employeeRepository.Getgrade();

        //    ViewBag.Designations = designations;
        //    ViewBag.Grades = grades;

        //    return View(employee);
        //}

        //[HttpPost]
        //public async Task<IActionResult> Update(Employee employee)
        //{
        //    if (ModelState.IsValid)
        //    {
        //        bool isUpdated = await _employeeRepository.UpdateEmployee(employee);
        //        if (isUpdated)
        //        {
        //            return RedirectToAction("EmployeeReport"); // Redirect after update
        //        }
        //        else
        //        {
        //            ModelState.AddModelError("", "Error updating employee.");
        //        }
        //    }

        //    // Repopulate dropdown lists if model state is invalid
        //    ViewBag.Designations = await _employeeRepository.GetDesignation();
        //    ViewBag.Grades = await _employeeRepository.Getgrade(employee.DesignationIdRef);

        //    return View(employee);
        //}

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}